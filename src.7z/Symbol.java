// wyliczenia pozwalają na elegancką reprezentację ograniczonego zbioru wartości
// w naszym przypadku pole może zawierać krzyżyk, kółko lub być puste
public enum Symbol {
	EMPTY,
	WHITE,
    BLACK
}
